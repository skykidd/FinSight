// lib/forecasting.dart

class ForecastingEngine {
  /// Takes a list of past monthly totals and predicts the next month's total
  /// using the Linear Regression formula (y = mx + b).
  static double predictNextMonth(List<double> pastMonthsData) {
    int n = pastMonthsData.length;

    // If we have no data, predict 0
    if (n == 0) return 0.0;

    // If we only have 1 month of data, we can't draw a trendline, so just return that month's value
    if (n == 1) return pastMonthsData.first;

    double sumX = 0;
    double sumY = 0;
    double sumXY = 0;
    double sumXX = 0;

    // Loop through the data to calculate our regression variables
    for (int i = 0; i < n; i++) {
      double x = (i + 1).toDouble(); // Month 1, Month 2, Month 3...
      double y = pastMonthsData[i]; // The RM amount spent that month

      sumX += x;
      sumY += y;
      sumXY += (x * y);
      sumXX += (x * x);
    }

    // Calculate the Slope (m) and Intercept (b)
    double slope =
        ((n * sumXY) - (sumX * sumY)) / ((n * sumXX) - (sumX * sumX));
    double intercept = (sumY - (slope * sumX)) / n;

    // Predict for the NEXT month
    double nextMonthX = (n + 1).toDouble();
    double prediction = (slope * nextMonthX) + intercept;

    // Expenses can't drop below RM 0 in reality, so cap it at 0
    return prediction < 0 ? 0.0 : prediction;
  }
}
